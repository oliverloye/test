
package dungeon;



public class Room {
    
    private int numberOfDoors;
    private int roomNumber;
    //int mats = ThreadLocalRandom.current().nextInt(1, 4 + 1);;
    private String discription;
    private String hint;
    
    public Room north;
    public Room east;
    public Room south;
    public Room west;

    public Room(int door, int roomNumber, String discription, String hint) {
        this.numberOfDoors = door;
        this.roomNumber = roomNumber;
        this.discription = discription;
        this.hint = hint;
        north = null; 
        south = null; 
        west = null; 
        east = null;
    }

    public int getNumbersOfDoors() {
        return numberOfDoors;
    }

    public void setNumbersOfDoors(int numbersOfDoors) {
        this.numberOfDoors = numbersOfDoors;
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(int roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getDiscription() {
        return discription;
    }

    public String getHint() {
        return hint;
    }

    public void setHint(String hint) {
        this.hint = hint;
    }
    
    @Override
    public String toString() {
        return "Room{" + "numbersOfDoors=" + numberOfDoors + ", roomNumber=" + roomNumber + '}';
    }

    
    
    
    
    
}
